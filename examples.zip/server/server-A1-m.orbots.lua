-- server-A1-m.orbots
-- RealName: "ServerUtils"

--#IMPORTS#--
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

--#VARIABLES#--
local MAX_HEALTH = 100
local playerData = {}

--#FUNCTIONS#--
local function InitializePlayer(player)
	playerData[player.UserId] = {health = MAX_HEALTH}
end

local function GetPlayerData(player_id)
	return playerData[player_id]
end

--#EVENTS#--
Players.PlayerAdded:Connect(function(player)
	InitializePlayer(player)
end)

Players.PlayerRemoving:Connect(function(player)
	playerData[player.UserId] = nil
end)

--#BASECODE#--
print("ServerUtils module initialized.")

--#RETURN#--
return {
	GetPlayerData = GetPlayerData,
	MAX_HEALTH = MAX_HEALTH
}
