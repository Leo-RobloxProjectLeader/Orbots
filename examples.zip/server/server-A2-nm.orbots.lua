-- server-A2-nm.orbots
-- RealName: "Controller"

--#IMPORTS#--
local ServerUtils = require(script.Parent:WaitForChild("server-A1-m"))
local Players = game:GetService("Players")

--#VARIABLES#--
local gameRunning = true
local UPDATE_INTERVAL = 2

--#FUNCTIONS#--
local function CheckPlayers()
	for _, player in pairs(Players:GetPlayers()) do
		local data = ServerUtils.GetPlayerData(player.UserId)
		if not data then continue end

		if data.health <= 0 then
			print(player.Name .. " is out of health!")
		end
	end
end

--#MAIN LOOP#--
while gameRunning do
	task.wait(UPDATE_INTERVAL)
	CheckPlayers()
end

--#BASECODE#--
print("Controller script initialized.")
