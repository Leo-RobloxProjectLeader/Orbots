-- client-A1-nm.orbots
-- RealName: "UIHandler"

--#IMPORTS#--
local Players = game:GetService("Players")
local player = Players.LocalPlayer

--#VARIABLES#--
local uiVisible = false
local TOGGLE_KEY = Enum.KeyCode.F

--#FUNCTIONS#--
local function ToggleUI()
	uiVisible = not uiVisible
	print("UI visibility set to:", uiVisible)
end

--#EVENTS#--
player:GetMouse().KeyDown:Connect(function(key)
	if key == TOGGLE_KEY.Name:lower() then
		ToggleUI()
	end
end)

--#BASECODE#--
print("UIHandler ready for", player.Name)
